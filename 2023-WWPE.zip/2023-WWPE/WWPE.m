clc
clear all
close all
addpath('Method');

images_dir='test';
listing = cat(1, dir(fullfile(images_dir, '*.jpg')));
results_dir = fullfile(images_dir, 'result');
if ~exist(results_dir, 'dir'), mkdir(results_dir); end

for i_img = 1:length(listing)
    Input = imread(fullfile(images_dir,listing(i_img).name));
    [~, img_name, ~] = fileparts(listing(i_img).name);
    img_name = strrep(img_name, '_input', '');
    CC = AMCC(Input); 
    Result = WWF(CC);
    imwrite(uint8(Result), fullfile(results_dir, [img_name, '_Result.jpg']));
end

